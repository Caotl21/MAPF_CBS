// filepath: /mnt/wsl_workspace/CBS/include/example.h
#ifndef EXAMPLE_H
#define EXAMPLE_H

void exampleFunction();


#endif // EXAMPLE_H