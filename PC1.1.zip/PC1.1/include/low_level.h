#ifndef LOW_LEVEL_H
#define LOW_LEVEL_H
#include <bits/stdc++.h>
#include "MapLoader.h"

struct agent
{
    std::vector<int > st;
    std::vector<int > ed;
    void set(int stx,int sty,int edx,int edy);
};

extern int num_agent;
extern agent* as;

struct stage{
    std::vector<int > post;
    std::vector<int > parent;
    int agent;
    std::vector<int > tvalid_agent;
    int g,h;
    int open = 0;
    void geth(std::vector<int > ed);
    void ptf();
};

struct Hashfunc {
    size_t operator() (const std::vector<int>& key) const;
};

struct Equalfunc {
    bool operator() (const std::vector<int>& a, const std::vector<int>& b) const;
};


struct stacmp{
    bool operator()(const std::vector<int>& a,const std::vector<int >& b) const;
};
bool ifvalid(std::vector<int > stnow ,int dx ,int dy ,std::vector<std::vector<int> > ct_point3s ,std::vector<std::vector<int > > ct_edge6s);


void explore(std::vector<int > stnow,int dx,int dy,std::priority_queue<std::vector<int >,std::vector<std::vector<int>>, stacmp > &open_list,std::vector<int >& edstage,std::vector<int > ed0);

int sta(agent* as,int i,std::vector<std::vector<int> > ct_point3s,std::vector<std::vector<int > > ct_edge6s,std::vector<std::vector<int > >& pths);

extern std::unordered_map<std::vector<int >,stage,Hashfunc,Equalfunc> hs;


#endif 