// filepath: /mnt/wsl_workspace/CBS/src/example.cpp
#include "example.h"
#include <iostream>

void exampleFunction() {
    std::cout<<"this is just a test print!"<<std::endl;
}