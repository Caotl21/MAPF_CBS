#include<bits/stdc++.h>
#include "low_level.h"
#include "MapLoader.h"


using namespace std;

int num_agent;

void agent::set(int stx,int sty,int edx,int edy)
{
    st.push_back(stx);
    st.push_back(sty);
    ed.push_back(edx);
    ed.push_back(edy);
}

agent* as;

void stage::geth(vector<int > ed){
        h = abs(post[0]-ed[0])+abs(post[1]-ed[1]);
}
void stage::ptf()
{
    printf("post is %d %d %d, g is %d, h is %d\n",post[0],post[1],post[2],g,h);
}



size_t Hashfunc::operator() (const vector<int>& key) const{
    return hash<int>()(key[0]) ^ hash<int>()(key[1]) ^ hash<int>()(key[2]);
}
bool Equalfunc::operator() (const vector<int>& a, const vector<int>& b) const{
    return a[0] == b[0] && a[1] == b[1] && a[2]==b[2];
}

unordered_map<vector<int >,stage,Hashfunc,Equalfunc> hs;

bool stacmp::operator()(const vector<int>& a,const vector<int >& b) const
{
    return (hs[a].g+hs[a].h)>(hs[b].g+hs[b].h);
}
bool ifvalid(vector<int > stnow ,int dx ,int dy ,vector<vector<int> > ct_point3s ,vector<vector<int > > ct_edge6s)
{
    int xnew = stnow[0] + dx;
    int ynew = stnow[1] + dy;
    int tnew = stnow[2] + 1;
    for(int i =0;i<ct_edge6s.size();++i)
    {
        if((stnow[0]==ct_edge6s[i][0])&&(stnow[1]==ct_edge6s[i][1])&&(stnow[2]==ct_edge6s[i][2])&&(xnew==ct_edge6s[i][3])&&(ynew==ct_edge6s[i][4])) return false;
    }
    for(int i=0;i<ct_point3s.size();++i)
    {
        if((xnew==ct_point3s[i][0])&&(ynew==ct_point3s[i][1])&&(tnew==ct_point3s[i][2])) return false;
    }

    if (!((xnew<ml.getHeight())&&(ynew<ml.getWidth())&&(xnew>=0)&&(ynew>=0))) return false;
    if(ml.getMapData(xnew,ynew)==-1) return false;
    else if(ml.getMapData(xnew,ynew)>0) return !tnew>=ml.getMapData(xnew,ynew);
    return true;
}

// to be optimize
void explore(vector<int > stnow,int dx,int dy,priority_queue<vector<int >,vector<vector<int>>, stacmp > &open_list,vector<int >& edstage,vector<int > ed0)
{
    vector<int > stnew;
    stnew.push_back(stnow[0]+dx);
    stnew.push_back(stnow[1]+dy);
    stnew.push_back(stnow[2]+1);
    auto it = hs.find(stnew);
    if(it!=hs.end())
    {
        if(hs[stnew].open==1)
        {
            if(hs[stnow].g+1 < hs[stnew].g)
            {
                hs[stnew].g = hs[stnow].g + 1;
                hs[stnew].parent = stnow;
                open_list.push(stnew);
            }
        }
    }
    else
    {
        stage newst;
        newst.post = stnew;
        newst.geth(ed0);
        newst.g = hs[stnow].g + 1;
        newst.open = 1;
        newst.parent = stnow;
        hs[stnew] = newst;
        open_list.push(stnew);
        if((stnew[0]==ed0[0])&&(stnew[1]==ed0[1])) edstage = stnew;
    }
}
int sta(agent* as,int i,vector<vector<int> > ct_point3s,vector<vector<int > > ct_edge6s,vector<vector<int > >& pths)
{
    ml.setMapData(as[i].ed[0],as[i].ed[1],0);
    
    vector<int > st0 = as[i].st;
    vector<int > ed0 = as[i].ed;

    if(ml.getMapData(ed0[0],ed0[1])) 
    {
        cout<<"end point is not valid"<<endl;
        return -1;
    }
    stage st;
    int res = 0;
    vector<int > edstage;
    st.post = st0;
    st.post.push_back(0);
    st.g = 0;
    st.geth(ed0);
    hs[st.post] = st;
    priority_queue<vector<int>,vector<vector<int >>,stacmp> open_list;
    open_list.push(st.post);
    hs[st.post].open = 1;
    vector<vector<int > > pathnow;
    while(!open_list.empty())
    {
        vector<int > stnow = open_list.top();
        open_list.pop();
        if(stnow[0]==ed0[0]&&stnow[1]==ed0[1])
        {
            pathnow.push_back(stnow);
            pths = pathnow;
            break;
        }
        if(hs[stnow].open==1)
        {
            if(ifvalid(stnow,0,0,ct_point3s,ct_edge6s))  explore(stnow,0,0,open_list,edstage,ed0);
            if(ifvalid(stnow,1,0,ct_point3s,ct_edge6s))  explore(stnow,1,0,open_list,edstage,ed0);
            if(ifvalid(stnow,0,1,ct_point3s,ct_edge6s))  explore(stnow,0,1,open_list,edstage,ed0);
            if(ifvalid(stnow,0,-1,ct_point3s,ct_edge6s))  explore(stnow,0,-1,open_list,edstage,ed0);
            if(ifvalid(stnow,-1,0,ct_point3s,ct_edge6s))  explore(stnow,-1,0,open_list,edstage,ed0);
        }
        hs[stnow].open = -1;
        if(edstage.size())
        {
            res = hs[edstage].g;
            vector<int > itter=edstage;
            pathnow.push_back(itter);
            while(itter[2])
            {
                itter = hs[itter].parent;
                pathnow.push_back(itter);
                pths = pathnow;
            }
            break;
        }
    }

    ml.setMapData(as[i].ed[0],as[i].ed[1],res);

    hs.clear();
    return res;
}
