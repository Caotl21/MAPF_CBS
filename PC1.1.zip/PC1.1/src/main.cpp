#include <bits/stdc++.h>
#include "example.h"
#include "ScenarioLoader.h"
#include "MapLoader.h"
#include "high_level.h"

using namespace std;

void handle_alarm(int signal) {
    cout << "Timeout!" << endl;
    exit(0);
}


// to do     bug ,CBSH

int main() {

    signal(SIGALRM, handle_alarm);

    alarm(60);

    std::cout << "Welcome to the CBS project!" << std::endl;
    exampleFunction();

    ml.loadMap("/mnt/wsl_workspace/CBS/benchmark/random-32-32-10/random-32-32-10.map");//绝对路径

    ScenarioLoader sl("/mnt/wsl_workspace/CBS/benchmark/random-32-32-10/random-32-32-10-random-1.scen");//绝对路径
    cout<<"Num of Experiments "<<sl.GetNumExperiments()<<endl;

    int n;
    n = 38; //best solve n = 38 with PC  38 903,
    int standardcost = 0;
    as = new agent[n];
    for(int i=0;i<n;++i)
    {
        Experiment exp = sl.GetNthExperiment(i);
        as[i].set(exp.GetStartY(),exp.GetStartX(),exp.GetGoalY(),exp.GetGoalX());
    }
    
    int runres = runCBS(as,n,true);
    cout<<"Runres"<<runres<<endl;

    alarm(0);

    return 0;
}